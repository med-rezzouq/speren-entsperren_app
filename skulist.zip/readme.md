#execute files in this order : index , sku , setproducts, exist, genenrate
